# Kumyalı Estate & Construction – website

Static site: `index.html` + `assets/`. No build step.

## Deploy
1. Push this folder to a GitHub repo.
2. In Vercel: Add New > Project > import the repo. Framework Preset: Other. Leave build command and output directory empty. Deploy.

## Before going public
- Replace the sample project images in `assets/` with Kumyalı's own project photos.
- Confirm the WhatsApp number in `index.html` (search for 905338649696).
